// BookingRepository.java - placeholder
package com.carrental.dao;

public class BookingDao {

}
