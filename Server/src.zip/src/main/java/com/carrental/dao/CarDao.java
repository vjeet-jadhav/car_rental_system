// CarRepository.java - placeholder
package com.carrental.dao;

import com.carrental.entity.Car;

public class CarDao {

}
