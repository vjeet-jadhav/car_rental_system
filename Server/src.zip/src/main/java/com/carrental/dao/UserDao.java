// UserRepository.java - placeholder
package com.carrental.dao;

public class UserDao {

}
