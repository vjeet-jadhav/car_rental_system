package com.carrental.entity;

public enum UserStatus {
	ACTIVE,INACTIVE
}
