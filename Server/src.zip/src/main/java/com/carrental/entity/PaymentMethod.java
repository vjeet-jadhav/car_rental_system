package com.carrental.entity;

public enum PaymentMethod {
	CREDIT_CARD, DEBIT_CARD, PAYPAL, UPI

}
