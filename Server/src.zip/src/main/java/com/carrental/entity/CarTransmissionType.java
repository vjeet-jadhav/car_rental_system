package com.carrental.entity;

public enum CarTransmissionType {
	MANUAL, AUTOMATIC
}
