package com.carrental.entity;

public enum CarStatus {

	PENDING, BOOKED, AVAILABLE, VERIFIED, NOTVERIFIED, DELETED, REJECTED

}
