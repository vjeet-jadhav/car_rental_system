package com.carrental.entity;

public enum BookingStatus {
	PENDING, CONFIRMED, CANCELLED 
}
