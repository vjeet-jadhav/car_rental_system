package com.carrental.entity;

public enum PaymentStatus {
 PENDING, COMPLETED, FAILED, CANCELLED
}
