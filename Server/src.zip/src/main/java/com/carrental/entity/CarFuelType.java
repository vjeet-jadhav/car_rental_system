package com.carrental.entity;

public enum CarFuelType {
	PETROL, DIESEL, ELECTRICAL, CNG
}
