package com.carrental.entity;

public enum UserRole {
	ADMIN,USER,HOST,AGENT
}
