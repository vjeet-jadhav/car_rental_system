// AuthController.java - placeholder
package com.carrental.controller;


public class AuthController {
	
}
