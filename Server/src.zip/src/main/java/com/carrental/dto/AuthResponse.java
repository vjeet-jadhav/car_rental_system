// AuthResponse.java - placeholder
package com.carrental.dto;

public class AuthResponse {

}
