// AuthRequest.java - placeholder
package com.carrental.dto;

public class AuthRequest {

}
