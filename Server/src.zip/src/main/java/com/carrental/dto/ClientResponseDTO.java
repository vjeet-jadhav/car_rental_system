package com.carrental.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
public class ClientResponseDTO {

	private String firstName;
	
	private String lastName;
	
}
