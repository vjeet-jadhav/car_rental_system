// AuthEntryPoint.java - placeholder
package com.carrental.config;

public class AuthEntryPoint {

}
