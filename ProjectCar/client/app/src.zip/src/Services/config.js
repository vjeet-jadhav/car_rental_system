export const config={
    serverUrl:'http://localhost:8080'
}